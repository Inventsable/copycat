// Typescript is not supported by Animate.
console.log('Host script is online')